package com.kpmg.authentication;
/*
*  Copyright (c) 2005-2012, WSO2 Inc. (http://www.wso2.org) All Rights Reserved.
*
*  WSO2 Inc. licenses this file to you under the Apache License,
*  Version 2.0 (the "License"); you may not use this file except
*  in compliance with the License.
*  You may obtain a copy of the License at
*
*    http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing,
* software distributed under the License is distributed on an
* "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
* KIND, either express or implied.  See the License for the
* specific language governing permissions and limitations
* under the License.
*/

import com.kpmg.authentication.internal.KPMGServiceComponent;
import org.apache.axis2.context.MessageContext;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.cxf.jaxrs.model.ClassResourceInfo;
import org.apache.cxf.message.Message;
import org.osgi.framework.BundleContext;
import org.wso2.carbon.core.services.authentication.AuthenticationFailureException;
import org.wso2.carbon.core.services.authentication.AuthenticationUtil;
import org.wso2.carbon.registry.core.config.RegistryContext;
import org.wso2.carbon.registry.core.session.UserRegistry;
import org.wso2.carbon.user.api.UserStoreException;
import org.wso2.carbon.user.api.UserStoreManager;
import org.wso2.carbon.user.core.UserRealm;
import org.wso2.carbon.user.core.service.RealmService;
import org.wso2.carbon.user.core.tenant.TenantManager;
import org.wso2.carbon.utils.multitenancy.MultitenantUtils;
import org.apache.cxf.jaxrs.ext.RequestHandler;

import javax.ws.rs.core.Response;
import java.util.ArrayList;
import java.util.Map;

public class UsernameBasedAuthenticator implements RequestHandler {

    private static final String AUTHENTICATOR_NAME = "KPMGUserNameBasedAuthenticator";
    private static final String AUTHENTICATION_HEADER = "KPMGHeader";
    private static final int PRIORITY_LEVEL = 4;
    private static final Log log= LogFactory.getLog(UsernameBasedAuthenticator.class);


    public boolean isAuthenticated(MessageContext msgContext) {
        return false;
    }

    public Response handleRequest(Message message, ClassResourceInfo classResourceInfo) {
        ArrayList<String> headers = ((Map<String, ArrayList>) message.get(Message.PROTOCOL_HEADERS)).get(AUTHENTICATION_HEADER);
        String userName=null;
        if (headers != null) {
            userName = headers.get(0);
        }
        log.info("User name:::: "+ userName);

        String tenantDomain = MultitenantUtils.getTenantDomain(userName);
        String tenantAwareUserName = MultitenantUtils.getTenantAwareUsername(userName);
        log.info("Tenant aware user name:::: "+ tenantAwareUserName);
        String userNameWithTenantDomain = tenantAwareUserName + "@" + tenantDomain;


        RealmService realmService = RegistryContext.getBaseInstance().getRealmService();
        TenantManager mgr = realmService.getTenantManager();
        try {
            UserStoreManager userStoreManager=realmService.getBootstrapRealm().getUserStoreManager();
            boolean isUserExist=userStoreManager.isExistingUser("SUPERTENANT/"+tenantAwareUserName);
            if(isUserExist){
                return null;
            }
            else{
                if (log.isDebugEnabled()) {
                    log.debug("Authentication request with an invalid username : " + userName);
                }
                throw new RuntimeException("Authentication request with an invalid username." + userName);
            }
        } catch (org.wso2.carbon.user.core.UserStoreException e) {
            e.printStackTrace();
        } catch (UserStoreException e) {
            e.printStackTrace();
        }

        int tenantId = 0;
        try {
            tenantId = mgr.getTenantId(tenantDomain);

            // tenantId == -1, means an invalid tenant.
            if (tenantId == -1) {
                if (log.isDebugEnabled()) {
                    log.debug("Basic authentication request with an invalid tenant : " + userNameWithTenantDomain);
                }
                throw new RuntimeException("Basic authentication request with an invalid tenant." + userNameWithTenantDomain);
            }
            else{
                return null;
            }

        } catch (UserStoreException e) {
            throw new RuntimeException("Error occurred while initializing AuthenticationFilter.",e);
        }
     /*   log.info("Tenant User name:::: "+ tenantAwareUserName);
        if (userName != null) {
            // if a username is present, then we authenticate..
            return null;
        }else {
            log.error("Authentication failure..");
            throw new RuntimeException("Error occurred while initializing AuthenticationFilter.");

        }*/
    }
}
